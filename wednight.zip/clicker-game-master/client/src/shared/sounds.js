const myaudio = new Audio(require('../music/Lounge.wav'))
export default myaudio
